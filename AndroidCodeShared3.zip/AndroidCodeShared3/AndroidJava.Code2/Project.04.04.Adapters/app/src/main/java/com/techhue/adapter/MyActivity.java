package com.techhue.adapter;

import android.app.Activity;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import java.util.ArrayList;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        final ListView myListView = (ListView) findViewById(R.id.my_list_view);

        // Row Layout File
        int layoutID = android.R.layout.simple_list_item_1;

        /**
         *  Creating and applying an Adapter
         */

        /*
        // Data Source
        ArrayList<String> myStringArray = new ArrayList<String>();

        // Controller or Middle Man
        // Registering Layout and Data Source With Adapter
        ArrayAdapter<String> myAdapterInstance;
        myAdapterInstance =
                new ArrayAdapter<String>(this, layoutID, myStringArray);

        // Registering Adapter With ListView
        myListView.setAdapter(myAdapterInstance);

        // Adding Data To Data Source
        myStringArray.add("The");
        myStringArray.add("quick");
        myStringArray.add("green");
        myStringArray.add("Android");
        myStringArray.add("jumped");
        myStringArray.add("over");
        myStringArray.add("the");
        myStringArray.add("Ding");
        myStringArray.add("Dong");
        myStringArray.add("Ping");
        myStringArray.add("Pong");
        myStringArray.add("Ding");
        myStringArray.add("Dong");
        myStringArray.add("Dong");
        myStringArray.add("Android");
        myStringArray.add("jumped");
        myStringArray.add("over");
        myStringArray.add("THE");

        // Telling Controller i.e. Adapter Data Set Changed
        // Then Controller i.e. Here Adapter Will Inform ListView
        myAdapterInstance.notifyDataSetChanged();

        */

        /**
         * Listing 4-21: Using Customized Array Adapter with MyClass.
         **/

        // MODEL : DATA SOURCE
        ArrayList<MyClass> myClassesArray = new ArrayList<MyClass>();
        myClassesArray.add(new MyClass("khojo"));
        myClassesArray.add(new MyClass("mojo"));
        myClassesArray.add(new MyClass("tojo"));
        myClassesArray.add(new MyClass("dojo"));
        myClassesArray.add(new MyClass("Pojo"));
        myClassesArray.add(new MyClass("Aojo"));
        myClassesArray.add(new MyClass("Bojo"));
        myClassesArray.add(new MyClass("Cojo"));
        myClassesArray.add(new MyClass("Tojo"));
        myClassesArray.add(new MyClass("Mojo"));
        myClassesArray.add(new MyClass("Aojo"));
        myClassesArray.add(new MyClass("Bojo"));
        myClassesArray.add(new MyClass("Jojo"));
        myClassesArray.add(new MyClass("Kojo"));
        myClassesArray.add(new MyClass("Uojo"));
        myClassesArray.add(new MyClass("Vojo"));

        // CONTROLLER
        // Registering -> Row Layout and Data Source
        MyArrayAdapter myArrayAdapter = new MyArrayAdapter(this, layoutID,
                                                myClassesArray);
        // Registering Adapter With List View
        myListView.setAdapter(myArrayAdapter);


        /**
         * Listing 4-22: Creating a Simple Cursor Adapter
         */
        /*
        LoaderManager.LoaderCallbacks<Cursor> loaded = new LoaderManager.LoaderCallbacks<Cursor>()
        {
            public Loader<Cursor> onCreateLoader(int id, Bundle args)
            {
                CursorLoader loader = new CursorLoader(MyActivity.this, CallLog.CONTENT_URI, null, null, null, null);
                return loader;
            }

            public void onLoadFinished(Loader<Cursor> loader, Cursor cursor)
            {

                String[] fromColumns = new String[] {
                        CallLog.Calls.CACHED_NAME,
                        CallLog.Calls.NUMBER
                };

                int[] toLayoutIDs = new int[] {
                        R.id.nameTextView,
                        R.id.numberTextView
                };

                SimpleCursorAdapter myCursorAdapter = new SimpleCursorAdapter(MyActivity.this, R.layout.mysimplecursorlayout, cursor, fromColumns, toLayoutIDs);
                myListView.setAdapter(myCursorAdapter);
            }

            public void onLoaderReset(Loader<Cursor> loader)
            {

            }
        };

        getLoaderManager().initLoader(0, null, loaded);
        */
    }
}