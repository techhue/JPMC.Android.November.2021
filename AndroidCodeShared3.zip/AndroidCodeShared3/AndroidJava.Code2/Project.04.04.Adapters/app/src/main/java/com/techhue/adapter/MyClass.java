package com.techhue.adapter;

public class MyClass
{
//    public Image image:
    public String name;
//    punlic String title:
//    public String subTitle;
//    punlic String date;

    public MyClass(String name)
    {
        this.name = name;
    }
}
