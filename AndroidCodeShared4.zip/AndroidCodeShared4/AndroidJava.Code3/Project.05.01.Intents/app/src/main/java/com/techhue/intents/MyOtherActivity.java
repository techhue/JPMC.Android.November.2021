package com.techhue.intents;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

// Activity B : MyOtherActivity
public class MyOtherActivity extends Activity {

    /**
     * Listing 5-14: Finding the launch Intent in an Activity
     */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
//        setContentView(R.layout.main);
        setContentView(R.layout.selector_layout);

        Log.d( "MyOtherActivity", " Method onCreate Getting Called" );

        // Will Return Intent Which Launched This Activity i.e. MyOtherActivity
        Intent intent = getIntent();
        String action = intent.getAction();
        Uri data = intent.getData();

        // Write Logic Based On Payload/Data Got With Intent...

    }


    @Override
    public void onStart() {
        super.onStart();
        Log.d( "MyOtherActivity", " Method onStart Getting Called" );

//        setContentView(R.layout.selector_layout);
        // ListView is Dummy ListView Without Any Data
        final ListView listView = (ListView) findViewById(R.id.listView1);

        // Find Ok and Cancel Button
        // Registering onClickListeners

        Button okButton = (Button) findViewById(R.id.ok_button);

        okButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                long selected_id = listView.getSelectedItemId();
                Log.d( "MyOtherActivity", " Method OK Button onClick Getting Called" );

                // Message With Payload To Be Sent From Activity B To Activity A
                Intent result = new Intent(Intent.ACTION_PICK, Uri.parse(Long.toString(selected_id)));

                // Sends Intent Back To Activity A i.e. MyActivity
                setResult(RESULT_OK, result);
                // Like Pressing Back Button
                // Finishing Activity i.e. Popped From Activity Stack
                finish();
            }
        });

        Button cancelButton = (Button) findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                setResult(RESULT_CANCELED);
                finish(); // Does Same Job as Back Button Pressed
            }
        });
    }
}