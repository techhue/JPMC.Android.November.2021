package com.techhue.broadcastintents;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyActivity extends Activity {
    /**
     * Listing 5-12: Registering and unregistering a Broadcast Receiver in code
     */
    public final static String TAG = "MyActivity : ";

    private IntentFilter filter =
            new IntentFilter(LifeformDetectedReceiver.NEW_LIFEFORM);

    private LifeformDetectedReceiver receiver =
            new LifeformDetectedReceiver();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate Called");

        setContentView(R.layout.main);
        // registerReceiver(receiver, filter);

        Button lifeFormButton = (Button) findViewById(R.id.newLifeFormButton);
        TextView lifeFormLabel = (TextView) findViewById(R.id.newLifeFormLabel);

        lifeFormButton.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                detectedLifeform("Alien", 12.000, -56.000);
            }
        });

    }

    @Override
    public synchronized void onResume()
    {
        super.onResume();
        Log.d(TAG, "onResume Called - Registering Receiver...");

        // Register the broadcast receiver AT Code Level
        registerReceiver(receiver, filter);
    }

    @Override
    public synchronized void onPause()
    {
        // UnRegister the broadcast receiver AT Code Level
        Log.d(TAG, "onPause Called - UNRegistering Receiver...");

        unregisterReceiver(receiver);
        super.onPause();
    }

    //
    private void detectedLifeform(String detectedLifeform, double currentLongitude, double currentLatitude)
    {
        Log.d(TAG, "detectedLifeform Called...");

        // Message About New Life Announcement
        // IMPLICIT INTENT with Action Specified
        Intent intent = new Intent(LifeformDetectedReceiver.NEW_LIFEFORM);

        // Adding Payload To Intent
        // Name of New Life Form Along With Location Where It's Found
        intent.putExtra(LifeformDetectedReceiver.EXTRA_LIFEFORM_NAME,
                detectedLifeform);
        intent.putExtra(LifeformDetectedReceiver.EXTRA_LONGITUDE,
                currentLongitude);
        intent.putExtra(LifeformDetectedReceiver.EXTRA_LATITUDE,
                currentLatitude);

        Log.d(TAG, "detectedLifeform Called... Sending Broadcast");
        sendBroadcast(intent);
    }
}