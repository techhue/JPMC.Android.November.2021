/*
kotlinc 03KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

package learnKotlin

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

// By Default View type is final, so it cannot be inherited from
open class View {
	// By Default : 'click' in 'View' is final and cannot be overridden
	open fun click() = println("View Is Clicked!")
}

// Inheritance
class Button: View() {
	// error: 'click' hides member of supertype 'View' and needs 'override' modifier
	override fun click() = println("Button Is Clicked!")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
}

// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}



