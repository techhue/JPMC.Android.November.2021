/*
kotlinc 02KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
*/

package learnKotlin

// _________________________________________________________________

fun collectionsInKotlin() {
	val hset = hashSetOf(10, 20, 70, 100)
	val list = arrayListOf(10, 20, 70, 100)
	val map  = hashMapOf(1 to "One", 10 to "Ten", 70 to "Seventy")

	println(hset.javaClass)
	println(list.javaClass)
	println(map.javaClass)

	val strings = listOf("first", "second", "third", "nine")
	println( strings.last() )
	println(strings.javaClass)

	val set = setOf(10, 20, 20, 100)
	println(set.javaClass)	

// Function : collectionsInKotlin
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// nine
// class java.util.Arrays$ArrayList
// class java.util.LinkedHashSet
}

// _________________________________________________________________

// Every Value Has Type
// 		Value Is Not Fundamental Rather Type Is

fun typeInferencingAndBinding() {
	// Type of some???
	// Expression
	// LHS = RHS
 	// 1. Infer Type From RHS Value
 	// 2. Bind The Type With LHS
	
	val some = "Good Morning"
	println(some)

	// Explcitly Specifying Type Annotation of LHS 
	//  error: type mismatch: inferred type is String but Int was expected
	// val someAgain: Int = "Good Morning!!!!!"
	val someAgain: String = "Good Morning!!!!!"
	println(someAgain)

 	// 1. Infer Type From RHS Value Is Int
 	// 2. Bind The Int Type With LHS	
	val some1 = 90
	println(some1)

 	// 1. Infer Type From RHS Value Is Int
 	// 2. Explicitly Bind The Int Type With LHS
	val someAgain1: Int = 900
	println(someAgain1)

	val something = 90.80
	println(something)

	val somethingAgain: Double = 90.80
	println(somethingAgain)

	val someFloat = 90.80F
	println(someFloat)

	val something1 = 'A'
	println(something1)

	val somethingAgain1: Char = 'A'
	println(somethingAgain1)
}

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

// T Is A Type Placeholder and It's Not Type
// T Will Be Substituted By A Type
//		Type Will Be Inferenced From Usage
//		And Will Be Replaced At Compile Time By The Compiler
fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder(prefix)

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append(separator)
		result.append(element)
	}
	result.append(postfix)
	
	return result.toString()
}

// Compiler Will Generate Following Code
// fun <ArrayList> joinToString(
// 	collection: Collection<ArrayList>,
// 	separator: String,
// 	prefix: String,
// 	postfix: String
// ) : String {

// 	val result = StringBuilder(prefix)

// 	for( (index, element) in collection.withIndex() ) {
// 		if ( index > 0 ) result.append(separator)
// 		result.append(element)
// 	}
// 	result.append(postfix)
	
// 	return result.toString()
// }

// Compiler Will Generate Following Code
// fun <HashSet> joinToString(
// 	collection: Collection<HashSet>,
// 	separator: String,
// 	prefix: String,
// 	postfix: String
// ) : String {

// 	val result = StringBuilder(prefix)

// 	for( (index, element) in collection.withIndex() ) {
// 		if ( index > 0 ) result.append(separator)
// 		result.append(element)
// 	}
// 	result.append(postfix)
	
// 	return result.toString()
// }

fun playWithJoinToString() {
	val strings = listOf("first", "second", "third", "nine")
	// Type Inferencing Will Happen
	// strings Inferred As ArrayList Type
	println( joinToString( strings, "; ", "(", ")") )
	// T Will Be Replaced With ArrayList	

	val numbers = hashSetOf(10, 20, 30, 40, 90, 100, -200, 80)	
	println( joinToString( numbers, " : ", "[ ", " ]") )	
	// T Will Be Replaced With HashSet	
}

// Function : playWithJoinToString
// (first; second; third; nine)
// [ 10 : 20 : 30 : 40 : 90 : 100 : -200 : 80 ]

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

// Adding More Functionality To String Class
// What Mechanisms You Will Use???

// 1st Approach: Modifiy Exisitng Source Code
// class String {
// 	fun lastChar() : Char {
// 		return this.get( string.length -1 )
// 	} 
// }

// 2nd Approach Using Inheritance
// class MyJazzyString extend String {

// 	fun lastChar() : Char {
// 		return this.get( string.length -1 )
// 	} 

	// fun dancingString() {

	// }
// }

//1. Modify The Existing String 
//		By Adding Methods In String Class Definition

//2. Create New Class By Inheriting String Class
//		Add Methods In This New Class Definition

fun lastChar(string: String) : Char {
	return string.get( string.length -1 )
} 

// 3rd Approach : Add Functionality Using Extension Methods
// Extention Functions
// 		lastCharacter() Is An Extension Function On Type String
// 		lastCharacter Function Get Binded With Existing String Type
fun String.lastCharacter() : Char {
	return this.get( this.length -1 )
} 

fun playWithLastCharacter() {
	var character = lastChar( "Welcome To India!")
	println(character)

	character = lastChar("Ding Dong$#")
	println(character)	

	character = "Welcome To India!".lastCharacter()
	println(character)

	character = "Ding Dong$#".lastCharacter()
	println(character)	
}

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

// Extension Function On Type Collection<T> With Default Arguments
fun <T> Collection<T>.joinToStringExtension(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder(prefix)

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append(separator)
		result.append(element)
	}
	result.append(postfix)
	
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val strings = listOf("first", "second", "third", "nine")
	// Type Inferencing Will Happen
	// strings Inferred As ArrayList Type
	println( strings.joinToStringExtension( "; ", "(", ")") )
	// T Will Be Replaced With ArrayList	

	println( strings.joinToStringExtension( separator = "; ", prefix = "(", 
		postfix = ")") )
	println( strings.joinToStringExtension( prefix = "(", postfix = ")") )

	println( strings.joinToStringExtension() )
	println( strings.joinToStringExtension( "; ") )
	println( strings.joinToStringExtension( "; ", "(" ) )

	val numbers = hashSetOf(10, 20, 30, 40, 90, 100, -200, 80)	
	println( numbers.joinToStringExtension( "; ", "(", ")") )
	// T Will Be Replaced With HashSet	
	println( numbers.joinToStringExtension() )
	println( numbers.joinToStringExtension( " : " ) )
	println( numbers.joinToStringExtension( " : ", " [ ") )
}

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

fun Collection<String>.join(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) = joinToStringExtension(separator, prefix, postfix)

fun playWithJoinExtension() {
	val strings = listOf("first", "second", "third", "nine")
	println( strings.join( "; ", "(", ")") )
	println( strings.join( separator = "; ", prefix = "(", 
		postfix = ")") )
	println( strings.join( prefix = "(", postfix = ")") )

	println( strings.join() )
	println( strings.join( "; ") )
	println( strings.join( "; ", "(" ) )

	// Error join Is Implemented On Collection<String> Only
	// val numbers = hashSetOf(10, 20, 30, 40, 90, 100, -200, 80)	
	// println( numbers.join( "; ", "(", ")") )
}

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

// Extension Properties

// lastChar Is Immutable An Extension Property On Type String
//		Only Getter Is Allowed
val String.lastChar: Char
	get() = get( length - 1 )

// lastChar Is Mutable An Extension Property On Type StringBuilder
//		Both Getter And Setter Is Allowed
var StringBuilder.lastChar: Char
	get() = get( length - 1 )
	set(value: Char) {
		this.setCharAt( length - 1, value)
	}

fun playWithExtensionProperties() {
	var character = "Welcome To India!".lastChar
	println(character)

	character = "Ding Dong$#".lastChar
	println(character)	

	var sb = StringBuilder("Welcome To India!")
	println( sb.lastChar )

	sb = StringBuilder("Ding Dong$#")
	println( sb.lastChar )	
}

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

// Local Functions

fun moveTowardsZero(start: Int) : Int {
	// Local Functions
	// 		Functions Defined Inside Function	
	val something = "Local Data"
	fun moveForward(start: Int): Int { 
		return start + 1
	}

	fun moveBackward(start: Int) = start - 1

	return if ( start > 0 ) moveBackward(start) else moveForward(start)
}

fun playWithLocalFunctions() {
	println( moveTowardsZero( 10 ))
	println( moveTowardsZero( -10 ))
}


// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

fun main() {
	println("\nFunction : collectionsInKotlin")
	collectionsInKotlin()

	println("\nFunction : typeInferencingAndBinding")
	typeInferencingAndBinding()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoinExtension")
	playWithJoinExtension()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithLocalFunctions")
	playWithLocalFunctions()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}



