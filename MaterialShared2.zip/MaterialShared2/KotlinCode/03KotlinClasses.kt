/*
kotlinc 03KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

package learnKotlin

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

// Design Principle
//		
//		 Best Practices Are Getting Incoporated

// In Kotlin 
// 		Classes Are By Default Final
//		Member Functions Are By Default Final
// In Java 
//		Classes Are By Defalut Open
//		Member Functions Are By Default Open

// By Default View type is final, so it cannot be inherited from
open class View {
	// By Default : 'click' in 'View' is final and cannot be overridden
	open fun click() = println("View Is Clicked!")
}

// Inheritance
class Button: View() {
	// error: 'click' hides member of supertype 'View' and needs 'override' modifier
	override fun click() = println("Button Is Clicked!")
	fun magic() = println("Button Magic!")
}

// Extension Functions Doesn't Participate In Inheritance Diagram
fun View.showOff() 		= println("View Extention Function")
fun Button.showOff() 	= println("Button Extention Function")

fun playWithInheritance() {
	// Type of vo Will Be View
	println("View Object....")
	val vo = View()
	vo.click()  // View Is Clicked!
	vo.showOff() // View Extention Function

	// Type of bo Will Be Button
	println("Button Object....")
	val bo = Button()
	bo.click()
	bo.magic()
	bo.showOff()

	// Parent Type Is Specifying Perceptive
	//	 	How Much Allows..
	println("Button Object Assigned To View Type....")
	val voAgain: View = Button()
	voAgain.click()
//	voAgain.magic()
	voAgain.showOff()
}

// Function : playWithInheritance
// View Object....
// View Is Clicked!
// View Extention Function

// Button Object....
// Button Is Clicked!
// Button Magic!
// Button Extention Function

// Button Object Assigned To View Type....
// Button Is Clicked!
// View Extention Function


fun playWithExtentionFunction() {
	val vo = View()
	vo.showOff()

	val bo = Button()
	bo.showOff()

	val voAgain: View = Button()
	voAgain.showOff()
}

// ____________________________________________________

// DESIGN PRINCIPLE
//		Design Towards Abstract Types Rather Than Concrete Types

//		Corollary
// 		BEST PRACTICE
//			Design Towards Interface Rather Than Concrete Classes

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

interface Clickable {
	fun click()
	fun showOff(click: Boolean) = println("Clickable ShowOff")
}

interface Focusable {
	fun setFocus() = println("Focusable setFocus")
	fun showOff(click: Boolean)  = println("Focusable ShowOff")
}

// error: class 'Button1' must override public open fun showOff(): Unit 
// 		defined in learnKotlin.Clickable 
// 		because it inherits multiple interface methods of it
class Button1: Clickable, Focusable {
	override fun click() = println("Button1 Clicked")

	override fun showOff(click: Boolean) {
		if (!click) super<Focusable>.showOff(false) 
		else super<Clickable>.showOff(false)
	}
}

fun playWithMultipleInterfaces() {
	val button = Button1()

	button.click()
	button.setFocus()
	button.showOff(true)
}

// ____________________________________________________

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr 


fun eval(e: Expr) : Int {
	// Type of e Is Expr

	// Smart Type Check
	// e is Num Is Checking Type Num
	// 		If True Then Type Cast e To Num Type
	if (e is Num) {
		// Type of e Will Be Num
		return e.value
	}

	// Type of e Is Expr
	if (e is Sum) {
		// Type of e Will Be Sum
		return eval(e.left) + eval(e.right)
	}

	throw IllegalArgumentException("Unknown Expression")
}

fun playWithEval() {
	// 100 + 200
	println( eval( Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
    println( eval(Sum(Sum(Num(100), Num(200)), Num(99))))
}

fun evalIf(e: Expr) : Int = 
	if (e is Num) {
		e.value
	} else if (e is Sum) {
		evalIf(e.left) + evalIf(e.right)
	} else {
		throw IllegalArgumentException("Unknown Expression")
	}

fun playWithEvalIf() {
	// 100 + 200
	println( evalIf(Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
    println( evalIf(Sum(Sum(Num(100), Num(200)), Num(99))))
}

fun evaluate(e: Expr) : Int = when(e) {
	is Num -> e.value
	is Sum -> evaluate(e.left) + evaluate(e.right)
	else -> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate(Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
    println( evaluate(Sum(Sum(Num(100), Num(200)), Num(99))))
}

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

sealed class Expr1 {
	class Num(val value: Int) : Expr1()
	class Sum(val left: Expr1, val right: Expr1) : Expr1()
}

fun evaluateAgain(e: Expr1) : Int = when(e) {
	is Expr1.Num -> e.value
	is Expr1.Sum -> evaluateAgain(e.left) + evaluateAgain(e.right)
}

fun playWithEvaluateAgain() {
	// 100 + 200
	println( evaluateAgain( Expr1.Sum( Expr1.Num(100), Expr1.Num(200) ) ) )

	// (100 + 200) + 99
    println( evaluateAgain(Expr1.Sum(Expr1.Sum(Expr1.Num(100), Expr1.Num(200)), 
    	Expr1.Num(99))))
}


// ____________________________________________________


class Client(val name: String, val postalCode: Int) {
	override fun toString() = "Client(name=$name, postalCode=$postalCode"
	
	override fun equals(other : Any?) : Boolean {
		if ( other == null || other !is Client) return false
		return name == other.name && postalCode == other.postalCode
	}
}

fun playWithClient() {
	val client = Client("Alice", 99999)
	println(client)
	println(client.name)
	println(client.postalCode)

	val client1 = Client("Alice", 99999)
	println(client1)

	val client2 = Client("Alice", 99999)
	println(client2)

	println( client1 == client2 )
}


// ____________________________________________________

// Data Class
// Compiler Will Generate Following Functions Code
//		1. toString() Method Code Using All Properties
//		2. equals() Method Code Based On Equality of All Properties
//		3. hashCode() Method Code Based On All Properties
//		4. copy() Method Code To Duplicate Object

data class Client1(val name: String, val postalCode: Int)

fun playWithClient1() {
	val client = Client1("Alice", 99999)
	println(client)
	println(client.name)
	println(client.postalCode)

	val client1 = Client1("Alice", 99999)
	println(client1)

	val client2 = Client1("Alice", 99999)
	println(client2)

	println( client1 == client2 )

	val client3 = client1.copy(postalCode = 777777 )
	println(client3)
}

// ____________________________________________________

// Object Classes In Kotlin
// 		Are Singleton Classes
//		Classes Having Only One Instance

object India {
	fun name(): String {
		return "Hindustan!"
	}
}

fun playWithSingleton() {
	val data = India.name()
	println( data )
}

// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : playWithExtentionFunction")
	playWithExtentionFunction()

	println("\nFunction : playWithMultipleInterfaces")
	playWithMultipleInterfaces()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithEvalIf")
	playWithEvalIf()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	println("\nFunction : playWithClient")
	playWithClient()

	println("\nFunction : playWithClient1")
	playWithClient1()

	println("\nFunction : playWithSingleton")
	playWithSingleton()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}



