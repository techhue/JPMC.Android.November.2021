

package learnKotlin

/*
kotlinc 05KotlinLambdas.kt -include-runtime -d lambdas.jar
java -jar lambdas.jar
*/


// ____________________________________________________

// Design Principle
// 		Always Design Towards Non Nullability Rather Nullability

data class Person(val name: String, val age: Int)

fun findTheOldest(people: List<Person> ) {
    var maxAge = 0
    var theOldest: Person? = null

    for (person in people) {
        if (person.age > maxAge) {
            maxAge = person.age
            theOldest = person
        }
    }
    println(theOldest)
}

fun playWithTheOldest() {
    val people = listOf(Person("Alice", 29), Person("Bob", 31))
    findTheOldest(people)
}


// ____________________________________________________

// Higher Order Functions
//		Functions Which Takes Functions As Arguments
// 			e.g. calculator is Higher Order Function

// Polymorphism
//		By Passing Function To Function
fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val aa = 10
	val bb = 30

	var result: Int

	val sumLambda = { a: Int, b: Int -> a + b }  // Lambda Expression
	result = calculator(aa, bb, sumLambda)
	println(result)

	val subLambda = { a: Int, b: Int -> a - b }  // Lambda Expression
	result = calculator(aa, bb, subLambda)
	println(result)
}


// ____________________________________________________

// Higher Order Function As Extension
//		Functions Which Takes Functions As Arguments

fun String.fliter(predicate : (Char) -> Boolean ) : String {
	
	val constructString = StringBuilder()
	for ( index in 0 until length ) {
		val element = get(index)

		if ( predicate( element ) ) constructString.append( element )
	}

	return constructString.toString()
}

fun playWithFilterExtension() {

	val something = "ab1d45deABCmmm"
	val criteriaLambda = { character : Char -> character in 'a'..'z' }
	val result = something.filter( criteriaLambda )

	println( result )
}


// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!



fun main() {
	println("\nFunction : playWithTheOldest")
	playWithTheOldest()

	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithFilterExtension")
	playWithFilterExtension()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}




