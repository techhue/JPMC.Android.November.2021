
package learnKotlin

/*
kotlinc 06KotlinHigherOrderFunctions.kt -include-runtime -d hof.jar
java -jar hof.jar
*/

// ____________________________________________________

fun sum(a: Int, b: Int) = a + b
fun sub(a: Int, b: Int) = a - b
fun mul(a: Int, b: Int) = a * b
fun div(a: Int, b: Int) = a / b

// Higher Order Functions
//		Functions Which Takes Functions As Arguments
//		Functions Which Retuns Functions
// 			e.g. calculator is Higher Order Function

// Polymorphism
//		By Passing Function To Function
fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 10
	val b = 30

	var result: Int

	result = calculator(a, b, ::sum)
	println(result)

	result = calculator(a, b, ::sub)
	println(result)

	result = calculator(a, b, ::mul)
	println(result)

	result = calculator(b, a, ::div)
	println(result)
}


// ____________________________________________________

// Higher Order Functions
//		Functions Which Retuns Functions

fun chooseSteps(backward: Boolean) : (Int) -> Int {
	fun moveForward(start: Int): Int { 
		return start + 1
	}

	fun moveBackward(start: Int): Int {
		return start - 1
	}

	return if ( backward ) ::moveBackward else ::moveForward
}

fun playWithChooseStepsFunction() {
	val something = chooseSteps(backward = true)
	val somethingAgain = chooseSteps(backward = false)

	println( something( 10 ))
	println( something( -10 ))

	println( somethingAgain( 10 ))
	println( somethingAgain( -10 ))
}

// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!



fun main() {
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithChooseStepsFunction")
	playWithChooseStepsFunction()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}




