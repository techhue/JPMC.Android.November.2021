
#include <stdio.h>

int sum(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }

// Polymorphic
int calculator(int a, int b, int (*operation)(int, int) ) {
        return operation(a, b);
}

int main() {
        int a = 10, b = 30;
        int result = 0;

        // Passing Function To Function
        result = calculator(a, b, sum);
        printf("\n Result : %d", result );

        // Passing Function To Function
        result = calculator(a, b, sub);
        printf("\n Result : %d", result );
}



