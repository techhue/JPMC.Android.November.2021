/*
kotlinc Hello.kt -include-runtime -d hello.jar
java -jar hello.jar
*/

package learnKotlin

fun main() {
	println("Hello World!")
}
