
#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doKuchipudiDance() {
	printf("\nDoing Kuchipudi Dance");
}

int main() {
	// Can I Say h Is An Object/Instance of Human Type
	//         Constructor 
	Human h = { 101, "Gabbar Singh", doKuchipudiDance };

	printf(" ID: %d, NAME: %s ", h.id, h.name );
	h.dance(); //
}

