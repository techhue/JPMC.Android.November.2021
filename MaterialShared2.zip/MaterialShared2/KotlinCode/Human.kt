
package learnKotlin

// What It Should Do
// 		Not How It Should Do

// Abstract Type = { Operations, Phi }

// Superpower Abstract Type = { { fly, SaveWorld }, Phi }

// Design By Definition
// 		Design Towards Abstract Type Rather Than Concete Type
//			Design Towards Interfaces Rather Than Concrete Classes
//			Protocol Driven Design
//			Behvaiour Driven Design

interface Superpower {
	fun fly()
	fun saveWorld()
}

interface MagicPower {

}

class Spiderman : Superpower, MagicPower {
	override fun fly() 		 = println("Fly Like Spiderman!")
	override fun saveWorld() = println("SaveWorld Like Spiderman!")
}

class Superman : Superpower {
	override fun fly() 		 = println("Fly Like Superman!")
	override fun saveWorld() = println("SaveWorld Like Superman!")
}

class Heman : Superpower {
	override fun fly() 		 = println("Fly Like Heman!")
	override fun saveWorld() = println("SaveWorld Like Heman!")
}

class WonderWomen : Superpower {
	override fun fly() 		 = println("Fly Like Heman!")
	override fun saveWorld() = println("SaveWorld Like Heman!")
}

// SOILD PRINCIPLES
//		S : Single Repsonbility Design
//      O : Open Close Principle
//			Classess Must Be Open For Extenstion Close For Modification

// BEST PRACTICE : Prefer Composition Over Inheritance

// class Human : Heman() {
// 	override fun fly() 		 = super.fly()
// 	override fun saveWorld() = super.saveWorld()
// }


// Design Principle
// 		Always Design Towards Non Nullability Rather Nullability


// HumanAgain Is Polymorphic
// Feature : HumanAgain Type Is Invariant

// Composition Design Pattern
class HumanAgain {
	var power : Superpower? = null
//	val anotherPower: MagicPower? = null 
	fun fly() 		 = power?.fly()  		// if (power != null ) power.fly() else null
	fun saveWorld()  = power?.saveWorld()   // if (power != null ) power.saveWorld() else null
}

fun main() {
	// val h = Human()
	// h.fly()
	// h.saveWorld()

	val ha = HumanAgain()
	ha.power = Spiderman()
	ha.fly()
	ha.saveWorld()

	ha.power = Superman()
	ha.fly()
	ha.saveWorld()

	ha.power = Heman()
	ha.fly()
	ha.saveWorld()

	ha.power = WonderWomen()
	ha.fly()
	ha.saveWorld()
}

